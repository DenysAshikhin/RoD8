
public class TESTER {

	public static void main(String[] args) {

		String[] wow = new String[2];
		wow[0] = "wow";
		wow[1] = "damn";
		
		String[] what = {wow[0], wow[1]};
		System.out.println(what[0] + what[1]);
 	//	System.out.println({wow[0], wow[1]});
	}

}
