<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Blocks" tilewidth="32" tileheight="32" tilecount="3" columns="3">
 <image source="blocks.png" width="96" height="32"/>
</tileset>
